import numpy as np
from gnuradio import gr

class blk(gr.sync_block):
    """Power estimator over complex vector frames"""
    def __init__(self, vlen=1024, power_mode="dbfs", eps=1e-12):
        gr.sync_block.__init__(
            self,
            name="power_estimator_vec",
            in_sig=[(np.complex64, int(vlen))],
            out_sig=[np.float32],
        )
        self.vlen = int(vlen)
        self.power_mode = power_mode.lower()
        self.eps = float(eps)

    def work(self, input_items, output_items):
        X = input_items[0]                  # shape: (nframes, vlen)
        # potencia lineal por frame: mean(|x|^2)
        p_lin = np.mean((X.real**2 + X.imag**2), axis=1)
        if self.power_mode == "dbfs":
            y = 10.0 * np.log10(np.maximum(self.eps, p_lin))
        else:
            y = p_lin.astype(np.float32)
        output_items[0][:len(y)] = y
        return len(y)